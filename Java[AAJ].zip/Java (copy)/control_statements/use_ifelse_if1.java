package control_statements;

import java.util.Scanner;

public class use_ifelse_if1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the city name : ");
        String city = sc.nextLine();
        if(city == "Banglore") {
            System.out.println("City Banglore");
        }
        else if (city == "Pune"){
            System.out.println("City Pune");
        }
        else if(city == "Mumbai"){
            System.out.println("City Mumbai");
        }
        else {
            System.out.println("City Agara");
        }
    }   
}
