package control_statements;

import java.util.Scanner;

public class Use_ifelse{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Value of A : ");
        int a = sc.nextInt();
        System.out.println("ENter the Value of B : ");
        int b = sc.nextInt();
        if(a+b >= 15) {
            System.out.println("The Number is Greater than 15"); 
        }
        else {
            System.out.println("The Number is Less than 15");
        }
    }
}