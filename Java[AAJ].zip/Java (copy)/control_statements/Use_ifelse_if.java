package control_statements;

import java.util.Scanner;

public class Use_ifelse_if {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String city = "Agara";

        if(city == "Banglore") {
            System.out.println("City Banglore");
        }
        else if (city == "Pune"){
            System.out.println("City Pune");
        }
        else if(city == "Mumbai"){
            System.out.println("City Mumbai");
        }
        else {
            System.out.println("City Agara");
        }
    }
    
}
 