package control_statements;

import java.util.Scanner;

public class Use_if {
     public static void main(String[] args) {
        int a;
        int b;

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Value of A : ");
        a = sc.nextInt();
        System.out.println("Enter the Value of B : ");
        b = sc.nextInt();
        if(a+b >10) {
            System.out.println("The Number is Greater than 10");
        }
    }
}
