package control_statements;

import java.util.Scanner;

public class Use_ifelse1 {
    public static void main(String[] args) {
        int c;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Value of A :");
        int a = sc.nextInt();
        System.out.println("Enter the Value of B : ");
        int b = sc.nextInt();
        c = a + b;
        if(c > 10) {
            System.out.println("The Addition of A+B is : " + c);
        }
        else{
            System.out.println("The Value is Less than 10");
        }

    }
}
