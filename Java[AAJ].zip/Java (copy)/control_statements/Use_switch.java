package control_statements;

public class Use_switch {
    public static void main(String[] args) {
        int n = 5;
        switch(n) {
            case 0 :
            System.out.println("Number is 0");
            break;
            case 1: 
            System.out.println("Number is 1");
            break;
            default : 
            System.out.println(n);
        }
    }
}
