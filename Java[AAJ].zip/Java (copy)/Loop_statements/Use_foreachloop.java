package Loop_statements;

//import java.util.Scanner;

public class Use_foreachloop {
    public static void main(String[] args) {
        //Scanner sc = new Scanner(System.in);
        //System.out.println("Enter the Word : ");
        //String names = sc.nextLine();
        String[] names = {"Abcd", "Cdef","Hijk"};
        for(String name: names) {
            System.out.println(names);
        }
    }
}
