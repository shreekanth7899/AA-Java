//Sum of First 10 Natural Numbers
package Loop_statements;

public class Use_forloop {
    public static void main(String[] args) {
        int num = 0;
        for(int i=1 ;i<10;i++) {
            num = num+i;
        }
        System.out.println("The Sum of First 10 Natural Number is : "+num);
    }
}
