package Arrays;

import java.util.Scanner;

public class Use_array2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Size of an Array : ");
        int Size = sc.nextInt();
        int marks[] = new int[Size];
        
        for(int i=0;i<Size;i++) {
            System.out.println("Enter the Values : ");
            marks[i] = sc.nextInt();
        }

        System.out.println("Enter the number to find x : ");
        int x = sc.nextInt();

        for(int i=0;i<Size;i++) {
            if(marks[i] == x) {
                System.out.println("X found at this index : " + i);
            }
            
        } 
        
    }
}
