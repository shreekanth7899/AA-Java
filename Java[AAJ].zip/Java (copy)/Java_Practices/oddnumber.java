package Java_Practices;

import java.util.Scanner;

public class oddnumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Number to check Odd or Not");
        int n = sc.nextInt();
        if(n %2 == 0) {
            System.out.println("The Number is Even");
        }
        else {
            System.out.println("The Number is Odd");
        }
    }
}
