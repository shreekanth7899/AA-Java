package Java_Practices;

import java.util.Scanner;

public class findxarray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int x;
        System.out.println("Enter the Number : ");
        int size = sc.nextInt();
        int marks[] = new int[size];
        System.out.println("Enter The values of Array : ");
        for(int i=0;i<size;i++) {
            marks[i] = sc.nextInt();
        }
        System.out.println("Enter the Value of X to find: ");
        x = sc.nextInt();
        for(int i=0;i<size;i++) {
            if(marks[i] == x) {
                System.out.println("The X index is" +marks[i]);
            }
        }

    }
}
