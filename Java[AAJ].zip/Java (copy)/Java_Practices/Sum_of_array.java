package Java_Practices;

public class Sum_of_array {
    public static void main(String[] args) {
        int sum = 0;
        int number[] = {21, 25, 50, 80,50};

        for(int i : number) 
        {
        sum = sum + i;
        }
        System.out.println(sum);
    }
}
