package Java_Practices;

public class swapnumber1 {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;

        System.out.println("Before Swaping, A is :" + a + "and B is : " +b);

        a = a+b;
        b = a-b;
        a = a-b;

        System.out.println("After Swaping, A is :" + a + " and B is : " +b);

    }
}
