//Program to Create an Array and Display the 3rd value

package Java_Practices;

import java.util.Scanner;

public class array1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Number to create an array : ");
        int Size = sc.nextInt();
        int marks[] = new int[Size];
        System.out.println("Enter the Values of Array : ");
        for(int i=0;i<Size;i++) {
            marks[i] = sc.nextInt();
        }
        System.out.println("The Marks of third person is :" +marks[3]);
    }
}
