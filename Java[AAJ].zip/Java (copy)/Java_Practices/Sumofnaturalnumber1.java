package Java_Practices;

import java.util.Scanner;

public class Sumofnaturalnumber1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int sum = 0;
        System.out.println("Enter the number : ");
        int n = sc.nextInt();
        for(int i=0;i<n;i++){
            sum += i;
        }
        System.out.println("Sum is :"+sum);
    }
}
