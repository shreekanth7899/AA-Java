//Create an Array and enter the values of 3 Array;

package Java_Practices;

import java.util.Scanner;

public class array {
    public static void main(String[] args) {
        int marks[] = new int[3];
        marks[0] = 89;
        marks[1] = 56;
        marks[2] = 99;
        System.out.println(marks[0]);
    }
}
