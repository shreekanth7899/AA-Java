package Java_Practices;

import java.util.Scanner;

public class test_fibonacciseries {
    public static void main(String[] args) {
            int a=0,b=1,c;
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter the value to display Fibonacci Series : ");
            int d = sc.nextInt();
            System.out.println(a +" "+b);
            for(int i=2;i<=d;i++) {
            c = a + b;
            System.out.println(" "+c);
            a=b;
            b=c;
        }
    }
}
