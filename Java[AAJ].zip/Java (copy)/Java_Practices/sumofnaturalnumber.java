package Java_Practices;

public class sumofnaturalnumber {
    public static void main(String[] args) {
        int sum = 0;
        int n = 10;
        for(int i=0;i<n;i++) {
            sum = sum + i; 
        }
        System.out.println("The Sum of "+n+"Natural number is : " +sum);
    }
}
