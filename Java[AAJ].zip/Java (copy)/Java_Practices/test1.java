package Java_Practices;

import java.util.Scanner;


public class test1 {
    public static void main(String[] args) {
        int a=0,b=1,c;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Number to get Fibonacci Series : ");
        int n = sc.nextInt();
        System.out.println(a+""+b);
        for(int i=2;i<n;i++) {
            c = a+b;
            System.out.println(""+c);
            a=b;
            b =c;
        }
    }
}
