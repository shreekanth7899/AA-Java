package Java_Practices;

import java.util.Scanner;

public class Swapnumber2 {
    public static void main(String[] args) {
        int a,b;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Value of A and B ");
        a = sc.nextInt();
        b = sc.nextInt();

        System.out.println("Before Swapping, A is : " + a + " and B is : " + b);
        a = a + b;
        b = a-b;
        a = a-b;
        System.out.println("After Swapping, A is : " + a + " and B is : " + b);
    }
}
